<div class="copyrights">
	 <p>TAW. All Rights Reserved |  <a href="#">TAW</a> </p>
</div>	
